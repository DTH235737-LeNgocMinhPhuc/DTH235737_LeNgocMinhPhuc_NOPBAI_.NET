﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bai6;
namespace Bai6
{ 
class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.Write("Nhập số lượng nhân viên: ");
            int n = int.Parse(Console.ReadLine());
            Console.Write("Nhập lương cơ bản: ");
            double basicSalary = double.Parse(Console.ReadLine());
            Employee.SetBasicSalary(basicSalary);
            Employee[] nhanViens = new Employee[n];

            Console.WriteLine("\nNhập thông tin nhân viên:");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("\nNhập thông tin nhân viên thứ: " + (i + 1));
                nhanViens[i] = new Employee();
                nhanViens[i].Input();
            }

            Console.WriteLine("\nDanh sách thông tin nhân viên:");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("\nThông tin nhân viên thứ: " + (i + 1));
                nhanViens[i].Display();
            }

            Console.ReadLine();
        }
    }
}

